import './App.css';
import React from 'react';
import EMICalc from './Components/EMICalc';

function App() {
  return (
    <div className="App">
      <EMICalc/>
    </div>
  )
}

export default App;
