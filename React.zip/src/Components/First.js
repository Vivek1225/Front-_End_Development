import React, {Component} from 'react';
class First extends Component{
    render(){
        return (
        <div>
            <h1>This is my first react component</h1>
            <p>React is a open source java sript library which is developed by jorden white in the year 2005</p>

        </div>
        );
    }
}

export default First;