import React from "react";
function Fchild(props){
    
    return(
        <div>
            <p>name : {props.name}</p>
            <p>Roll : {props.Roll}</p>
        </div>
    )
}
export default Fchild;