import FChildContext1 from "./FChildContext1";
import React from "react";

function FChildContext(){
    return(
        <div>
            <FChildContext1/>
        </div>
    )
}
export default FChildContext;